DROP TABLE IF EXISTS `#__virtuemart_payment_plg_payvector_gateway_entry_points`;
DROP TABLE IF EXISTS `#__virtuemart_payment_plg_payvector_card`;
